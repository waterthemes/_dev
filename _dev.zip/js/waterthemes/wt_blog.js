function runSliderBlog(){
						
				$("#wt-blog-slider").owlCarousel({
					responsive: {
						0: { items: 1},
						464:{ items: 1},
						750:{ items: 3},
						974:{ items: 3},
						1170:{ items: 4}
					},
				dots: true,
				nav: false,
				loop: true,
				margin: 0,
				slideSpeed : 500,
				paginationSpeed : 1000,
				scrollPerPage: true,
				lazyLoad: true,
				});
				
				$("#wt-blog-slider").trigger('refresh.owl.carousel');
							
		}
$(document).ready(function() {
		runSliderBlog();
		$('input[name=mode_css]').click(function(){
			runSliderBlog();
		});
}); 

$(window).resize(function(){
	runSliderBlog();
});