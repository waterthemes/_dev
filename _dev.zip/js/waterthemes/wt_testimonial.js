function runSliderTestimonial(){
							
							$("#wt_testimonial_content").owlCarousel({
							  loop: true,
								responsive: {
									0: { items: 1},
									464:{ items: 1},
									750:{ items: 1},
									974:{ items: 1},
									1170:{ items: 1}
								},
							  dots: true,
							  nav: false,
							  loop: true,
							  slideSpeed : 500,
							paginationSpeed : 1000,
							scrollPerPage: true,
							lazyLoad: true
							});
				
							
						}
$(document).ready(function() {
		runSliderTestimonial();
});

$(window).resize(function(){
	runSliderTestimonial();
});