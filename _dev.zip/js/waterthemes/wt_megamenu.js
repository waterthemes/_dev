function isMobileIpad() {
	if(navigator.userAgent.match(/Android/i) ||
		navigator.userAgent.match(/webOS/i) ||
		navigator.userAgent.match(/iPad/i) ||
		navigator.userAgent.match(/iPhone/i) ||
		navigator.userAgent.match(/iPod/i)
		){
			return true;
	}
	else return false;
}

function isMobile() {
	if(navigator.userAgent.match(/Android/i) ||
		navigator.userAgent.match(/webOS/i) ||
		navigator.userAgent.match(/iPhone/i) ||
		navigator.userAgent.match(/iPod/i)
		){
			return true;
	}
	else return false;
}
function getHtmlHide(nIpad,numLiItem) 
	{
				var htmlLiHide="";
				if($("#more_menu").length==0)
					for(var i=(nIpad+1);i<=numLiItem;i++)
						htmlLiHide+='<li>'+$('#wt-menu-horizontal ul.menu-content li.level-1:nth-child('+i+')').html()+'</li>';
				return htmlLiHide;
	}		
	

function addMoreResponsive(nIpadHorizontal,nIpadVertical,htmlLiH,htmlLiV,htmlMenu) 
{
	if(nIpadHorizontal>0 && nIpadVertical>0)
	{
		if($("#more_menu").length>0)
			$("#wt-menu-horizontal .container").html(htmlMenu);

		if($(window).width() > 750 && $(window).width() <= 992)
		{	
			if($("#more_menu").length==0)
			{
				$('<li id="more_menu" class="level-1 more-menu"><a href="#"><span class="icon-plus"></span>' + text_more + '</a><ul class="menu-dropdown cat-drop-menu wt-sub-auto">' + htmlLiV + '</ul></li>').insertAfter('#wt-menu-horizontal ul.menu-content li.level-1:nth-child('+nIpadVertical+')');
			}
			if($("#more_menu").length>0)
				for(var j=(nIpadVertical+2);j<=(numLiItem+1);j++)
				{
					$("#wt-menu-horizontal ul.menu-content li:nth-child("+j+").level-1").remove();
					var delItem=nIpadVertical+2;
					$("#wt-menu-horizontal ul.menu-content li:nth-child("+delItem+").level-1").remove();
				}
		}
		else if($(window).width() > 992 && $(window).width() <= 1199)
		{
			
			if($("#more_menu").length==0)
				$('<li id="more_menu" class="level-1 more-menu"><a href="#"><span class="icon-plus"></span>' + text_more + '</a><ul class="menu-dropdown cat-drop-menu wt-sub-auto">' + htmlLiH + '</ul></li>').insertAfter('#wt-menu-horizontal ul.menu-content li.level-1:nth-child('+nIpadHorizontal+')');
			if($("#more_menu").length>0)
				for(var j=(nIpadHorizontal+2);j<=(numLiItem+1);j++)
				{
					$("#wt-menu-horizontal ul.menu-content li:nth-child("+j+").level-1").remove();
					var delItem=nIpadHorizontal+2;
					$("#wt-menu-horizontal ul.menu-content li:nth-child("+delItem+").level-1").remove();
				}
		}
	}
}

$(document).ready(function()
{
		numLiItem = $("#wt-menu-horizontal .menu-content li.level-1").length;
		nIpadHorizontal =5;
		nIpadVertical = 6;
		htmlLiH = getHtmlHide(nIpadHorizontal,numLiItem);
		htmlLiV = getHtmlHide(nIpadVertical,numLiItem);
		htmlMenu=$("#wt-menu-horizontal").html();	
		
		addMoreResponsive(nIpadHorizontal,nIpadVertical,htmlLiH,htmlLiV,htmlMenu);
	$(document).on('click', '#wt-menu-horizontal .icon-drop-mobile', function() {
		
	});
	if($(window).width() < 768)
	{
		$('#wt-menu-horizontal ul.menu-content').css('display', 'none');
		
	}
	$(window).resize(function(){
		numLiItem = $("#wt-menu-horizontal .menu-content li.level-1").length;
		nIpadHorizontal =5;
		nIpadVertical = 6;
		htmlLiH = getHtmlHide(nIpadHorizontal,numLiItem);
		htmlLiV = getHtmlHide(nIpadVertical,numLiItem);
		htmlMenu=$("#wt-menu-horizontal").html();	
		if($(window).width() < 768)
		{
			$('#wt-menu-horizontal ul.menu-content').css('display', 'none');
			
		}
		else
		{
			addMoreResponsive(nIpadHorizontal,nIpadVertical,htmlLiH,htmlLiV,htmlMenu);
			$('#wt-menu-horizontal ul.menu-content').css('display', 'block');
		}
	});
});




$(window).resize(function(){
	
	addMoreResponsive(nIpadHorizontal,nIpadVertical,htmlLiH,htmlLiV,htmlMenu);
	
	if(!isMobileIpad() && $(window).width() < 1007)
	{
		$('#wt-menu-horizontal').removeClass('wt-menu-sticky animated');
	}
});
function menuHorClick()
{
	$(document).on('click', '.wt-menu-horizontal .title-menu-mobile', function() {
		
		
	});
	
}