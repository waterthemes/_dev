
$(function(){
		var loanding="<div class='wt-main-loading-overlay'><div class='wt_loading'><div class='loader'></div></div></div>";
	
	$("ul.product-list li .wt_container_thumbnail").hover(
		function(){
			var id_product = $(this).attr('wt-data-id-product');
			var name_module = $(this).attr('wt-name-module');
			var id_tab = $(this).attr('id-tab');
			if (id_tab != '')
				id_tab = '-'+id_tab;
			else
				id_tab = '';
			
			if ($('#'+name_module+id_tab+'-wt-thumbs-content-'+id_product).html() == '')
			{
				$('#'+name_module+id_tab+'-wt-thumbs-content-'+id_product).html(loanding);
				GetImages(name_module, id_tab, id_product);
			}
		},
		function(){
		});
	
		
	
	$( ".wt_home_filter_product_tab ul.title-tab li").click(function() {
		var loanding="<div class='wt-main-loading-overlay filter'><div class='wt_loading'><div class='loader'></div></div></div>";
		var type_tab = $(this).attr('type-tab');
		var id_tab = $(this).attr('id-tab');
		var name_module = $(this).attr('wt-name-module');
		
		$('#ul_tv_tab li').removeClass('ui-tabs-selected');
		$(this).addClass('ui-tabs-selected');
			$('#tabs-'+id_tab).show();
			$('#tabs-'+id_tab).html(loanding);
			GetProducts(name_module, id_tab, type_tab);
		
		
		});
	
});
$(window).ready(function() {
		runSliderHometab();
		$('input[name=mode_css]').click(function(){
			runSliderHometab();
		});
		
	});
$(window).resize(function()
{
	runSliderHometab();
});
$( document).ajaxComplete(function() {
  	$('.thumbs_list li a').hover(
		function(){
			displayThumbnailImage($(this));
			$(this).addClass('select');
		},
		function(){
		$(this).removeClass('select');
		});
		reloadFunction();
		
});

function runSliderHometab(){

		
			var i = 0;
		for (var tab in tabs) {
			i = i+1;
			owl = $('#carousel'+i);
			owl.owlCarousel({
					responsive: {
						0: { items: 2},
						464:{ items: 2},
						750:{ items: 3},
						974:{ items: 4},
						1170:{ items: 5},
						1620:{ items: 6}
					},
				  dots: false,
				  nav: true,
				  loop: true,
				  margin: 15,
				  slideSpeed : 500,
				  lazyLoad: true
				});
			owl.trigger('refresh.owl.carousel'); 
		}
	}

function reloadFunction(){
	var loanding="<p class='loading'></p>";
	$("ul.product-list li .wt_container_thumbnail").hover(
		function(){
			var id_product = $(this).attr('wt-data-id-product');
			var name_module = $(this).attr('wt-name-module');
			var id_tab = $(this).attr('id-tab');
			if (id_tab != '')
				id_tab = '-'+id_tab;
			else
				id_tab = '';
			if ($('#'+name_module+id_tab+'-wt-thumbs-content-'+id_product).html() == '')
			{
				$('#'+name_module+id_tab+'-wt-thumbs-content-'+id_product).html(loanding);
				GetImages(name_module, id_tab, id_product);
			}
		},
		function(){
		});
}

function displayThumbnailImage(domAAroundImgThumb, no_animation)
{
		if (typeof(no_animation) == 'undefined')
			no_animation = false;
		if (domAAroundImgThumb.prop('href'))
		{
			var new_src = domAAroundImgThumb.attr('tv-img-src').replace('thickbox', 'large');
			var new_title = domAAroundImgThumb.attr('title');
			var new_href = domAAroundImgThumb.attr('href');
			
			if (domAAroundImgThumb.parent().parent().parent().parent().parent().find('.wt-image').prop('src') != new_src)
			{
				domAAroundImgThumb.parent().parent().parent().parent().parent().find('.wt-image').attr({
					'src' : new_src,
					'alt' : new_title,
					'title' : new_title
				}).load(function(){
					if (typeof(jqZoomEnabled) != 'undefined' && jqZoomEnabled)
						$(this).attr('rel', new_href);
				});
			}
			$('.thumbs_list li a').removeClass('shown');
			$(domAAroundImgThumb).addClass('shown');
		}
	}
	
function GetImages(name_module, id_tab, id_product) {
		var url = $('#wt_home_filter_product_tab_ssl').attr('wt_base_ssl')+'modules/wtproductfilter/controller_ajax_images.php';
		$.post(
		    url, 
			{id_Product: id_product},
			function(data) 
			{ 
				$('#'+name_module+id_tab+'-wt-thumbs-content-'+id_product).html(data);
		});
}

function GetProducts(name_module, id_tab, type_tab) {
		
		var base_ssl = $('#wt_home_filter_product_tab_ssl').attr('wt_base_ssl')+'modules/wtproductfilter/controller_ajax_product.php';
		var url_page_cart = $('#wt_home_filter_product_tab_ssl').attr('url_page_cart');
		var static_token = $('#wt_home_filter_product_tab_ssl').attr('static_token');
		$.post(
		    base_ssl, 
			{id_Tab: id_tab, type_Tab: type_tab, name_Module: name_module, Url_Page_Cart :url_page_cart, Static_Token : static_token},
			function(data) 
			{ 	
				$('.tabs-carousel').hide();
				$('#tabs-'+id_tab).show();
				$('#tabs-'+id_tab).html(data);
			})
			.fail(function(error, textStatus, errorThrown) 
			{ 
				$('#tabs-'+id_tab).html(error.responseText);
			});
			
			
		
}
