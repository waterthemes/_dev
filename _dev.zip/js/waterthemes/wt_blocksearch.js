
$(function(){
	
	var loanding="<p class='loanding'></p>";
		var content_result = "<div id='wtsearch_content_result'><div class='over_light'></div><a href='javascript:void(0)' class='wt_close' id='close_search_query_nav'><span>close</span></a><div id='wtsearch_eccept_data'  class='wt-container'></div></div>";
		$(content_result).insertAfter("#search_block_top" );
		
	$('#search_query_nav').click(function(){
			
			$("#search_block_top").addClass('show');
		});
		
		$('#close_search_query_nav').click(function(){
			$('#wtsearch_content_result').slideUp(300);
			$("#search_block_top").removeClass('show');

		});
		
var searching = null;
	$('#searchbox input.search_query').keyup(function(){ 
	   $('.ac_results').remove();
	   $('#wtsearch_eccept_data').html(loanding);
		$('#wtsearch_content_result').slideDown(400);
		if(this.value.length<3)
		$('#wtsearch_eccept_data').html(limit_character);				
		else
		{
			var id_cat = $('#search_category').val();
			
			 if (searching) {
            clearTimeout(searching);
			}
			searching = setTimeout(function () {
            doLiveSearch($('#searchbox input.search_query').val(), id_cat);
			}, 500);
		}
		
	});
	
	$( "#search_category" ).change(function() {
		 $('#wtsearch_eccept_data').html(loanding);
		if($('#searchbox input.search_query').val().length < 3)
		{
			$('#wtsearch_eccept_data').html(limit_character);
		}
		else
		{
			var id_cat = $('#search_category').val();
			doLiveSearch($('#searchbox input.search_query').val(), id_cat);
		}
	});

});
function doLiveSearch(inputString, id_cat) {
		
		$.post(
		    $('#wt_url_ajax_search input.url_ajax').val(), 
			{queryString: inputString, id_Cat: id_cat},
			function(data) 
			{ 
				$('#wtsearch_eccept_data').html(data);
		});				
}

function Show_All_Search()
{
	$( "#searchbox" ).submit();
}