
$(document).ready(function(){
	if (!('ontouchstart' in document.documentElement) && $('.js-page-progress-bar').length) {
        Pace.start();
    }
   /* $(window).load(function() {
        setTimeout(function(){
            Pace.stop();
            $('.js-page-progress-bar').removeClass('js-page-progress-bar');
        }, 500);    
    });*/
				
});



