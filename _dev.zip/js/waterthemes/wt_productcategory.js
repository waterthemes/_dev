$(window).ready(function() {
	var loanding="<div class='wt-main-loading-overlay'><div class='wt_loading cat_pro'><div class='loader'></div></div></div>";
		$('.wt-prod-cat .sub-cat-ul .item_sub').click(function(){
		var id_cat = $(this).attr('id-cat');
		var id_group = $(this).attr('id-group');
		var number_prod = $(this).attr('number-prod');
		var name_module = $(this).attr('wt-name-module');
		
		$('.wt-prod-cat #sub-cat-ul-'+id_group+' .item_sub').removeClass('active');
		$(this).addClass('active');
		$('#content-product-sub-cat-'+id_group).append(loanding);
		getProductCat(id_group, id_cat, number_prod, name_module);
		 
		});
		
		if($(window).width() < 992 && ismobile != 1)
			runSliderProducstCat_Resize();
		else
			runSliderProducstCat();
		
		$('input[name=mode_css]').click(function(){
			runSliderProducstCat();
		});
	
	});

$(document).ajaxComplete(function(){
		runSliderProducstCat();
});
$(window).resize(function() {
		if($(window).width() < 992 && ismobile != 1)
			runSliderProducstCat_Resize();
		else
		{
			runSliderProducstCat(); 
		}
});

function runSliderProducstCat_Resize()
{
	
	for (var elem in group_cat_result) {  
	var group_cat_info = group_cat_result[elem]['cat_info'];
	var i = 0;
		for (var cat in group_cat_info) {
			i = i+1;
			owl = $('#cat-carousel-'+i);
			owl.owlCarousel({
					responsive: {
						0: { items: 1, dots: true, nav: false},
						464:{ items: 1, dots: true, nav: false},
						767:{ items: 1, dots: true, nav: false},
						992:{ items: 1, dots: false, nav: true},
						1190:{ items: 1, dots: false, nav: true},
						1570:{ items: 1, dots: false, nav: true}
					},
				  dots: false,
				  nav: true,
				  loop: true,
				  margin: 0,
				  slideSpeed : 500,
				  lazyLoad: true
				});
			owl.trigger('refresh.owl.carousel');
			$('#sub-cat-ul-'+i).owlCarousel({
					responsive: {
						0: { items: 2 },
						464:{ items: 2},
						750:{ items: 2},
						974:{ items: 4},
						1170:{ items: 6},
						1570:{ items: 8}
					},
				  dots: false,
				  nav: true,
				  loop: true,
				  margin: 0,
				  slideSpeed : 500,
				paginationSpeed : 1000,
				scrollPerPage: true
				});
			
			$('#manu-list-'+i).owlCarousel({
					responsive: {
						0: { items: 2 },
						464:{ items: 2},
						750:{ items: 2},
						974:{ items: 2},
						1170:{ items: 2}
					},
				  dots: true,
				  nav: false,
				  loop: true,
				  margin: 0,
				  slideSpeed : 500,
				paginationSpeed : 1000,
				scrollPerPage: true
				});
				
				
		}
	}	

}

function runSliderProducstCat()
{
	
	for (var elem in group_cat_result) {  
	var group_cat_info = group_cat_result[elem]['cat_info'];
	var i = 0;
		for (var cat in group_cat_info) {
			i = i+1;
			owl = $('#cat-carousel-'+i);
			owl.owlCarousel({
					responsive: {
						0: { items: 2, dots: true, nav: false},
						464:{ items: 2, dots: true, nav: false},
						767:{ items: 3, dots: true, nav: false},
						992:{ items: 1, dots: false, nav: true},
						1190:{ items: 1, dots: false, nav: true},
						1570:{ items: 1, dots: false, nav: true}
					},
				  dots: false,
				  nav: true,
				  loop: true,
				  margin: 0,
				  slideSpeed : 500,
				  lazyLoad: true
				});
			owl.trigger('refresh.owl.carousel');
			$('#sub-cat-ul-'+i).owlCarousel({
					responsive: {
						0: { items: 2 },
						464:{ items: 2},
						750:{ items: 2},
						974:{ items: 4},
						1170:{ items: 6},
						1570:{ items: 8}
					},
				  dots: false,
				  nav: true,
				  loop: true,
				  margin: 0,
				  slideSpeed : 500,
				paginationSpeed : 1000,
				scrollPerPage: true
				});
			
			$('#manu-list-'+i).owlCarousel({
					responsive: {
						0: { items: 2 },
						464:{ items: 2},
						750:{ items: 2},
						974:{ items: 2},
						1170:{ items: 2}
					},
				  dots: true,
				  nav: false,
				  loop: true,
				  margin: 0,
				  slideSpeed : 500,
				paginationSpeed : 1000,
				scrollPerPage: true
				});
				
				
		}
	}	

}	
function getProductCat(id_group, id_cat, number_prod, name_module) {
		var url_page_cart = $('#wt-prod-cat-base-ssl').attr('url_page_cart');
		var static_token = $('#wt-prod-cat-base-ssl').attr('static_token');
		
		$.post(
		    $('#wt-prod-cat-base-ssl').attr('wt_base_ssl'), 
			{id_Cat: id_cat, id_Group: id_group, number_Prod: number_prod, name_Module: name_module, Url_Page_Cart : url_page_cart, Static_Token : static_token},
			function(data) 
			{ 
				$('#content-product-sub-cat-'+id_group).html('');
				$('#content-product-sub-cat-'+id_group).html(data);
			})
			.fail(function(error, textStatus, errorThrown) 
			{ 
				$('#content-product-sub-cat-'+id_group).html(error.responseText);
			});
	
}



if(typeof Cufon == 'function') Cufon.replace('h1, h2, h3, h4, h5, h6');
 
$(document).ready(function() {
if(page_name == 'index')
{
	document.createElement('section');var duration=500,easing='swing';
	$('.bannerSetup').slides({ preload: true, generateNextPrev: false });
	var offset_cat = $('.wt-prod-cat').offset().top;
	var timeout,
		sections = new Array(),
		sectionscount = 0,
		win = $(window),
		sidebar = $('#cat-icon_sidebar'),
		nav = $('#wt-icon-category'),
		logo = $('#documenter_logo'),
		navanchors = nav.find('a'),
		timeoffset = 50,
		hash = location.hash || null;
		iDeviceNotOS4 = (navigator.userAgent.match(/iphone|ipod|ipad/i) && !navigator.userAgent.match(/OS 5/i)) || false,
		badIE = $('html').prop('class').match(/ie(6|7|8)/)|| false;
		
	//handle external links (new window)
	$('#cat-icon_sidebar a[href^=http]').bind('click',function(){
		window.open($(this).attr('href'));
		return false;
	});
	
	//IE 8 and lower doesn't like the smooth pagescroll
	if(!badIE){
		window.scroll(0,0);
		$('#wt-icon-category li a').bind('click touchstart',function(){
		
			hash = $(this).attr('href');
			$.scrollTo.window().queue([]).stop();
			goTo(hash);
			$('#wt-icon-category li a').removeClass('current');
			$(this).addClass('current');
			return false;
		});
		
		//if a hash is set => go to it
		if(hash){
			setTimeout(function(){
				goTo(hash);
			},500);
		}
	}
	
	
	//We need the position of each section until the full page with all images is loaded
	win.bind('load',function(){
		
		var sectionselector = 'section';
		
		//Documentation has subcategories		
		if(nav.find('ul').length){
			sectionselector = 'section, h3';
		}
		//saving some information
		$(sectionselector).each(function(i,e){
			var _this = $(this);
			var p = {
				id: this.id,
				pos: _this.offset().top,
			};
			sections.push(p);
		});
		
		
		//iPhone, iPod and iPad don't trigger the scroll event
		if(iDeviceNotOS4){
			nav.find('a').bind('click',function(){
				setTimeout(function(){
					win.trigger('scroll');				
				},duration);
				
			});
			//scroll to top
			window.scroll(0,0);
		}

		//how many sections
		sectionscount = sections.length;
		
		//bind the handler to the scroll event
		win.bind('scroll',function(event){
			clearInterval(timeout);
			//should occur with a delay
			timeout = setTimeout(function(){
				//get the position from the very top in all browsers
				pos = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
				
				//iDeviceNotOS4s don't know the fixed property so we fake it
				if(iDeviceNotOS4){
					sidebar.css({height:document.height});
					logo.css({'margin-top':pos});
				}
				//activate Nav element at the current position
				activateNav(pos);
			},timeoffset);
		}).trigger('scroll');

	});
	
	//the function is called when the hash changes
	function hashchange(){
		goTo(location.hash, false);
	}
	
	//scroll to a section and set the hash
	function goTo(hash,changehash){
		win.unbind('hashchange', hashchange);
		hash = hash.replace(/!\//,'');
		$('body,html').animate({        scrollTop: $(hash).offset().top - 50		}, 500);
		if(changehash !== false){
			var l = location;
			location.href = (l.protocol+'//'+l.host+l.pathname+'#!/'+hash.substr(1));
		}
		win.bind('hashchange', hashchange);
	}
	
	
	
	
	//activate current nav element
	function activateNav(pos){
		
		var offset = 0,
		current, next, parent, isSub, hasSub;
		win.unbind('hashchange', hashchange);
		for(var i=sectionscount;i>0;i--){
			if(sections[i-1].pos <= pos+offset){
				
				navanchors.removeClass('current');
				
				current = navanchors.eq(i-1);
				current.addClass('current');
				
				parent = current.parent().parent();
				next = current.next();
				
				hasSub = next.is('ul');
				isSub = !parent.is('#wt-icon-category');
				
				nav.find('ul:visible').not(parent).slideUp('fast');
				if(isSub){
					parent.prev().addClass('current');
					parent.stop().slideDown('fast');
				}else if(hasSub){
					next.stop().slideDown('fast');
				}
				win.bind('hashchange', hashchange);
				break;
			};
		}	
	}
	
	
}
	
});