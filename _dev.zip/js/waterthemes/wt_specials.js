function runSliderSpecial(){
						
						$('#wt_special_product').owlCarousel({
								responsive: {
									0: { items: 1 },
									464:{ items: 1},
									750:{ items: 1},
									974:{ items: 1},
									1170:{ items: 1},
									1670:{ items: 1}
								},
							  dots: true,
							  nav: true,
							  loop: true,
							  margin: 0,
							  slideSpeed : 1900,
							paginationSpeed : 1900,
							scrollPerPage: true,
							lazyLoad: true
							});
						$('#wt_special_product').trigger('refresh.owl.carousel');
							
						}
$(document).ready(function() {
		runSliderSpecial();
		$('input[name=mode_css]').click(function(){
			runSliderSpecial();
		});
});

$(window).resize(function(){
	runSliderSpecial();
});