$(document).ready(function()
{
$('.wt_countdown').countdown({
		autoStart: true,
	});
	
});