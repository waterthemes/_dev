
function runSliderViewed(){
	
	var viewed_html = $('#wt_container_viewed').html();
	$('#wt_container_viewed').remove();
	$('#wt_blockviewed').html(viewed_html);
	var check_viewed = $(viewed_html).find('.ajax_block_product').html();

	var num_item_view = $('#wt_viewed_product .ajax_block_product').length;
	var items_viewed = 2;
	if (num_item_view >=8 && $(window).width() > 1600)
	{
		items_viewed = 8;
		$('#wt_blockviewed').css('width','1200px');
	}
	else if(num_item_view >=6 && $(window).width() > 1200)
	{
		items_viewed = 6;
		$('#wt_blockviewed').css('width','1000px');
	}
	else if(num_item_view >=4 && $(window).width() > 992)
	{
		items_viewed = 4;
		$('#wt_blockviewed').css('width','800px');
	}
	else
	{
		items_viewed = 2;
		$('#wt_blockviewed').css('width','270px');
	}
	
	if (check_viewed != null) {
			var num_viewed = $('#wt_viewed_product').attr('number');
			$('.viewed-products-count').html('('+num_viewed+')');
					$('#wt_viewed_product').owlCarousel({
								responsive: {
								0: { items: 2 },
								464:{ items: 2},
								750:{ items: 2},
								974:{ items: items_viewed},
								1170:{ items: items_viewed},
								1670:{ items: items_viewed}
								},
								dots: true,
								nav: false,
								loop: true,
								margin: 15,
								slideSpeed : 500,
								paginationSpeed : 1000,
								scrollPerPage: true
		});	
	}

}

$(window).resize(function(){
	if(ps_viewedproduct)
	runSliderViewed();
});
$(document).ready(function(){
	if(ps_viewedproduct)
	{
	ViewedHover();
	runSliderViewed();
	}
				
});
function HoverWatcher1(selector)
{
	this.hovering = false;
	var self = this;

	this.isHoveringOver = function(){
		return self.hovering;
	}

	$(selector).hover(function(){
		self.hovering = true;
	}, function(){
		self.hovering = false;
	})
}
function ViewedHover()
{
	var ul_content_viewed = new HoverWatcher1("#wt_blockviewed");
	var title_wishlist= new HoverWatcher1(".blockviewed a.icon");
	
	$(".blockviewed a.icon").hover(
		function() {
			
			$(this).addClass('hover');
			$("#wt_blockviewed").slideDown(200);
			$("#wt_overlay1").show();
			
		},
		function() {
			setTimeout(function() {
				if (!ul_content_viewed.isHoveringOver() && !title_wishlist.isHoveringOver()){
					$("#wt_overlay1").hide();
					$('.blockviewed a.icon').removeClass('hover');
					$("#wt_blockviewed").hide();
				}
			}, 100);
		}
	);
	$("#wt_blockviewed").hover(
		function() {
		},
		function() {
			
			setTimeout(function() {
				if (!ul_content_viewed.isHoveringOver() && !title_wishlist.isHoveringOver()){
					$("#wt_overlay1").hide();
					$('.blockviewed a.icon').removeClass('hover');
					$("#wt_blockviewed").stop(true, true).hide();
				}
			}, 100);
		}
	);
}


