
$(document).ready(function(){
	
	if(linkajaxcart != null && page_name != 'cart')
	{
		if(!ismobile)
		{
			$('<div class="wtajaxcart"><div id="content_ajaxcart"></div></div>').insertAfter("#_desktop_cart .header" );
			RefreshCart();		
			CartHover();
			prestashop.on('updatedCart', function(event) {
			CartHover();
			$(".wtajaxcart").stop(true, true).slideDown(200);
			});
		}
		
		
	}
});

$(document).ajaxComplete(function() {
	if(linkajaxcart != null && page_name != 'cart' && ismobile != 1)
	{
		if ($('.wtajaxcart').html() == null)
		{
		$('<div class="wtajaxcart"><div id="content_ajaxcart"></div></div>').insertAfter("#_desktop_cart .header" );
			
			RefreshCart();
			CartHover();
		}
	}
	
});

function RefreshCart()
{
	
	$.ajax({
		type: 'GET',
		url: linkajaxcart+'?rand=' + new Date().getTime(),
		headers: { "cache-control": "no-cache" },
		async: true,
		data: 'action=loadcart',
		cache: false,
		success: function(data)
		{
			$('#content_ajaxcart').html(data);
		}
	});
	
}


function HoverWatcherCart(selector)
{
	this.hovering = false;
	var self = this;

	this.isHoveringOver = function(){
		return self.hovering;
	}

	$(selector).hover(function(){
		self.hovering = true;
	}, function(){
		self.hovering = false;
	})
}
function CartHover()
{
	//RefreshCart();
	var ul_content = new HoverWatcherCart(".wtajaxcart");
	var title = new HoverWatcherCart(".blockcart .header");
	
	$(".blockcart .header").hover(
		function() {
			$("#wt_overlay").show();
			$(this).addClass('hover');
			$(".wtajaxcart").stop(true, true).slideDown(200);
		},
		function() {
			setTimeout(function() {
				if (!ul_content.isHoveringOver() && !title.isHoveringOver()){
					$("#wt_overlay").hide();
					$('.blockcart .header').removeClass('hover');
					$(".wtajaxcart").stop(true, true).slideUp(100);
				}
			}, 100);
		}
	);
	$(".wtajaxcart").hover(
		function() {
		},
		function() {
			
			setTimeout(function() {
				if (!ul_content.isHoveringOver() && !title.isHoveringOver()){
					$("#wt_overlay").hide();
					$('.blockcart .header').removeClass('hover');
					$(".wtajaxcart").stop(true, true).slideUp(100);
				}
			}, 100);
		}
	);

}

