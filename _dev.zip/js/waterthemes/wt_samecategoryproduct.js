function runSliderCategoryProduct(){
						
						$('#ul_productscategory_list').owlCarousel({
								responsive: {
									0: { items: 2 },
									464:{ items: 2},
									750:{ items: 3},
									974:{ items: 4},
									1170:{ items: 5},
									1670:{ items: 6}
								},
							  dots: true,
							  nav: false,
							  loop: true,
							  margin: 0,
							  slideSpeed : 500,
							paginationSpeed : 1000,
							scrollPerPage: true,
							lazyLoad: true
							});
				
							
						}
$(document).ready(function() {
		runSliderCategoryProduct();
});

$(window).resize(function(){
	runSliderCategoryProduct();
});