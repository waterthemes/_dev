
$(window).load(function()
{
		$('#wt-menu-ver-left .icon-drop-mobile').click(function() {
		 $(this).next().toggle('slow');
		$(this).toggleClass('opened');
	});
	if($(window).width() > 767)
	{
		
		$("#index .wt-menu-ver-left .category-left").css('display','block');
		//menuVerHover();
		if($(window).width() < 992)
		{
			$(".vertical-menu-content").hide();
			$(".vertical-menu-content").removeClass('opened');
		}
	
	}	
	else
	{
		//$(".wt-menu-ver-left .vertical-menu-content").css('display','none');
		menuVerClick();
	}
		
	var width_menu_content = $('#wrapper .container').width() - $('#wt-menu-ver-left').width() - 40;
	
	$('#wt-menu-ver-left ul.menu-content li div.wt-sub-menu').each(function(index, element)
	{
		var width_sub = parseInt($(this).children('.v-menu-sub-width').val());
		if($(window).width() < 1024 && width_sub >= 6)
			width_sub = 12;
		if($(window).width() < 1024 && width_sub < 6)
			width_sub = 6;
		
		var width_sub_result = parseInt(width_menu_content/12*width_sub);
		$(this).width(width_sub_result);
	});
	if($(window).width() > 767)
	{
	
	
		  
		  $('#wt-menu-ver-left .category-title').click(function() {
			  if ($(".wt-menu-ver-left .vertical-menu-content").hasClass('opened'))
			{
				$(".wt-menu-ver-left .vertical-menu-content").stop(true, true).slideUp(300);
				$(".wt-menu-ver-left .vertical-menu-content").removeClass('opened');
				$(this).addClass('plus');
			}
			else
			{
				$(".wt-menu-ver-left .vertical-menu-content").stop(true, true).slideDown(600);
				$(".wt-menu-ver-left .vertical-menu-content").addClass('opened');
				$(this).removeClass('plus');
			}
			
		});
		
		$('#wt-menu-ver-left .category-left li.more, #wt-menu-ver-left .category-left li.hide').click(function() {
			  if ($("#wt-menu-ver-left .category-left li.more").is(':visible'))
			{
				$("#wt-menu-ver-left .category-left li.level-1.hide_li").show();
				$("#wt-menu-ver-left .category-left li.more").hide();
				$("#wt-menu-ver-left .category-left li.hide").show();
			}
			else
			{
				$("#wt-menu-ver-left .category-left li.level-1.hide_li").hide();
				$("#wt-menu-ver-left .category-left li.more").show();
				$("#wt-menu-ver-left .category-left li.hide").hide();
			}
			
		});
		
	

	}
	
	
});

$(window).resize(function()
{
	var width_menu_content = $('#wrapper .container').width() - $('#wt-menu-ver-left').width();
	$('#wt-menu-ver-left ul.menu-content li div.wt-sub-menu').each(function(index, element)
	{
		var width_sub = parseInt($(this).children('.v-menu-sub-width').val());
		if($(window).width() < 1024 && width_sub >= 6)
			width_sub = 12;
		if($(window).width() < 1024 && width_sub < 6)
			width_sub = 6;
		
		var width_sub_result = parseInt(width_menu_content/12*width_sub);
		$(this).width(width_sub_result);
	});
	
	if($(window).width() > 992)
	{
		$(".vertical-menu-content").show();
	}
	else if($(window).width() < 992 && $(window).width() > 767)
	{
		$(".vertical-menu-content").hide();
		menuVerHover();
	}

		
	
});
function HoverWatcher(selector)
{
	this.hovering = false;
	var self = this;

	this.isHoveringOver = function(){
		return self.hovering;
	}

	$(selector).hover(function(){
		self.hovering = true;
	}, function(){
		self.hovering = false;
	})
}
function menuVerHover()
{
	var ul_ver_menu = new HoverWatcher('.wt-menu-ver-page .category-left');
	var ver_menu_title = new HoverWatcher('.wt-menu-ver-page .category-title');
	
}
function menuVerClick()
{

		$('.wt-menu-ver-left .category-title').click(function() {
			if ($(".wt-menu-ver-left .vertical-menu-content").hasClass('slideDown'))
			{
				$(".wt-menu-ver-left .vertical-menu-content").stop(true, true).slideUp(300);
				$(".wt-menu-ver-left .vertical-menu-content").removeClass('slideDown');
				
			}
			else
			{
				$(".wt-menu-ver-left .vertical-menu-content").stop(true, true).slideDown(600);
				$(".wt-menu-ver-left .vertical-menu-content").addClass('slideDown');
				
			}
			
		});
		
}